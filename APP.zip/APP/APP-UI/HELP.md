1. Download and install nodejs

2. open cmd

3. Set the proxy:
npm config set proxy http://kn.proxy.int.kn:80

4. Install vue: 
npm install -g @vue/cli

5. Got to tms-ui folder in terminal and run command:
npm install

6. Run project:
npm run serve